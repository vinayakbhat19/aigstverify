-- Signals schema (run later, after Fiesta). RLS on every table.
create table profiles(id uuid primary key references auth.users on delete cascade, name text not null, college text, interests text[] default '{}', created_at timestamptz default now());
create table signals(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, title text not null check(char_length(title) between 3 and 80), kind text not null, place text not null, lat double precision, lng double precision, created_at timestamptz default now(), closed_at timestamptz);
create table messages(id bigint generated always as identity primary key, signal_id uuid not null references signals on delete cascade, sender uuid not null references profiles, body text not null check(char_length(body)<=500), created_at timestamptz default now());
create table events(id uuid primary key default gen_random_uuid(), host_id uuid not null references profiles, type text not null, name text not null, theme text, starts_at timestamptz, ends_at timestamptz, audience text not null default 'sdmcet' check(audience in('sdmcet','everyone','link')), live boolean default false, body jsonb default '{}');
create table registrations(event_id uuid references events on delete cascade, user_id uuid references profiles on delete cascade, paid boolean default false, checked_in boolean default false, primary key(event_id,user_id));
alter table profiles enable row level security; alter table signals enable row level security; alter table messages enable row level security; alter table events enable row level security; alter table registrations enable row level security;
create policy "own profile" on profiles for all using(id=auth.uid()) with check(id=auth.uid());
create policy "read open signals" on signals for select using(closed_at is null);
create policy "raise own" on signals for insert with check(user_id=auth.uid());
create policy "close own" on signals for update using(user_id=auth.uid());
create policy "read own chats" on messages for select using(sender=auth.uid() or exists(select 1 from signals s where s.id=signal_id and s.user_id=auth.uid()));
create policy "send as me" on messages for insert with check(sender=auth.uid());
create policy "read live events" on events for select using(live or host_id=auth.uid());
create policy "host manages" on events for all using(host_id=auth.uid()) with check(host_id=auth.uid());
create policy "own registration" on registrations for select using(user_id=auth.uid());
create policy "register me" on registrations for insert with check(user_id=auth.uid() and paid=false and checked_in=false);
-- paid / checked_in are changed only by SECURITY DEFINER functions the desk calls (mark_paid, check_in).
