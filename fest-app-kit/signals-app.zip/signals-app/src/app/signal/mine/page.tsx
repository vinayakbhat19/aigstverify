'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Shell, Back } from '@/components/Bits';
import { api, timeAgo, type Signal } from '@/lib/api';
export default function Mine() {
  const [s, setS] = useState<Signal[]>([]); useEffect(() => setS(api.mine()), []);
  return <Shell nav><Back href="/signal/"/><h1 className="t" style={{ marginTop: 10 }}>My signals</h1>
    {s.length === 0 ? <div style={{ marginTop: 28 }}><p className="mu" style={{ fontSize: 16 }}>You have not raised a signal yet.</p><Link href="/signal/raise/" className="btn lb">Raise one</Link></div>
      : <div className="card" style={{ marginTop: 18 }}>{s.map(x => <div key={x.id} className="row" style={{ padding: '10px 18px' }}><span style={{ flex: 1 }}><b>{x.title}</b><div className="mu" style={{ fontSize: 13, fontWeight: 500 }}>{x.where} · {timeAgo(x.ts)}</div></span><button onClick={() => { api.close(x.id); setS(api.mine()); }} style={{ height: 44, padding: '0 16px', borderRadius: 22, background: 'var(--s2)', fontWeight: 700 }}>Close</button></div>)}</div>}</Shell>;
}
