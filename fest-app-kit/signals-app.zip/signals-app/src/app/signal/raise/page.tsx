'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Shell, Back } from '@/components/Bits';
import { api, type Signal } from '@/lib/api';
const KINDS: Signal['kind'][] = ['Study', 'Sport', 'Food', 'Ride', 'Other'];
export default function Raise() {
  const r = useRouter(); const [title, setTitle] = useState(''); const [kind, setKind] = useState<Signal['kind']>('Study'); const [where, setWhere] = useState(''); const [done, setDone] = useState(false);
  if (done) return <Shell nav><div style={{ textAlign: 'center', paddingTop: 70 }}><div style={{ width: 96, height: 96, borderRadius: '50%', background: 'var(--lb)', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 44, color: 'var(--ink)' }}>✓</div><h1 className="t" style={{ marginTop: 22 }}>Signal raised</h1><p className="mu" style={{ fontSize: 16 }}>People nearby can see it now.</p><div style={{ marginTop: 26 }}><button className="btn lb" onClick={() => r.push('/signal/mine/')}>See my signals</button></div></div></Shell>;
  return <Shell nav><Back/><h1 className="t" style={{ marginTop: 10 }}>Raise your signal</h1>
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, margin: '20px 0 14px' }}>{KINDS.map(k => <button key={k} onClick={() => setKind(k)} aria-pressed={kind === k} style={{ height: 44, padding: '0 18px', borderRadius: 22, fontWeight: 700, background: kind === k ? 'var(--lb)' : 'var(--s1)', color: kind === k ? 'var(--ink)' : 'var(--tx)' }}>{k}</button>)}</div>
    <input className="inp" placeholder="What do you need?" value={title} maxLength={80} onChange={e => setTitle(e.target.value)}/>
    <input className="inp" placeholder="Where are you?" value={where} maxLength={60} onChange={e => setWhere(e.target.value)} style={{ marginTop: 12 }}/>
    <div style={{ marginTop: 18 }}><button className="btn lb" disabled={title.trim().length < 3 || !where.trim()} onClick={() => { api.raise({ title: title.trim(), kind, where: where.trim() }); setDone(true); }}>Raise signal</button></div></Shell>;
}
