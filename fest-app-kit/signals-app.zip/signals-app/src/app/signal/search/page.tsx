'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Shell, Back } from '@/components/Bits';
import { api, timeAgo, type Signal } from '@/lib/api';
export default function Search() {
  const [perm, setPerm] = useState<'ask' | 'denied' | 'ok'>('ask'); const [res, setRes] = useState<Signal[] | null>(null);
  const go = () => { if (!navigator.geolocation) { setPerm('ok'); return; } navigator.geolocation.getCurrentPosition(() => setPerm('ok'), () => setPerm('denied'), { timeout: 8000 }); };
  useEffect(() => { if (perm === 'ok') { const t = setTimeout(() => setRes(api.signals()), 2400); return () => clearTimeout(t); } }, [perm]);
  return <Shell nav><Back/>
    {perm === 'ask' && <><h1 className="t" style={{ marginTop: 10 }}>Use your location?</h1><p className="mu" style={{ fontSize: 16, lineHeight: '24px', margin: '12px 0 24px' }}>Signals only looks while you search. We never share your exact spot.</p><button className="btn c" onClick={go}>Allow location</button><button className="btn g" style={{ marginTop: 10 }} onClick={() => setPerm('ok')}>Not now, use campus</button></>}
    {perm === 'denied' && <><h1 className="t" style={{ marginTop: 10 }}>Location is off</h1><p className="mu" style={{ fontSize: 16, margin: '12px 0 24px' }}>You can still search the whole campus.</p><button className="btn c" onClick={() => setPerm('ok')}>Search campus instead</button></>}
    {perm === 'ok' && <>
      <div style={{ position: 'relative', height: 300, margin: '8px 0' }} role="status" aria-label={res ? 'Done' : 'Searching'}>{[110, 210, 290].map(w => <span key={w} className="ring" style={{ width: w, height: w }}/>)}{!res && <span className="sweep"/>}<span style={{ position: 'absolute', left: '50%', top: '50%', width: 18, height: 18, margin: '-9px 0 0 -9px', borderRadius: '50%', background: 'var(--c)', border: '3px solid #fff' }}/></div>
      <div className="card"><div style={{ padding: '16px 18px 8px' }}><b className="t" style={{ fontSize: 22 }}>{res ? `${res.length} signals nearby` : 'Looking for signals…'}</b></div>
        {!res ? [0, 1, 2].map(i => <div key={i} className="row"><span style={{ flex: 1 }}><div className="sk" style={{ width: '64%', height: 15 }}/><div className="sk" style={{ marginTop: 8, width: '40%', height: 11 }}/></span></div>)
          : res.map(x => <Link key={x.id} href={`/chat/?id=${x.id}`} className="row" style={{ padding: '10px 18px' }}><span style={{ flex: 1 }}><b>{x.title}</b><div className="mu" style={{ fontSize: 13, fontWeight: 500 }}>{x.by} · {x.where} · {timeAgo(x.ts)}</div></span><span style={{ fontSize: 13, fontWeight: 700, color: 'var(--c)' }}>{x.mins ? `${x.mins} min` : 'here'}</span></Link>)}
        <div style={{ padding: '12px 16px 16px' }}><Link href="/signal/raise/" className="btn lb">Or raise yours now</Link></div></div></>}
  </Shell>;
}
