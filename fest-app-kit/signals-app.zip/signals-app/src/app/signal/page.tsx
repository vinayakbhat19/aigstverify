'use client';
import Link from 'next/link';
import { Shell, Back } from '@/components/Bits';
export default function Choose() { return <Shell nav><Back href="/home/"/><h1 className="t" style={{ marginTop: 10 }}>Signal</h1><p className="mu" style={{ margin: '10px 0 20px', fontSize: 16 }}>What do you want to do?</p>
  <Link href="/signal/raise/" style={{ display: 'block', borderRadius: 30, background: 'var(--lb)', color: 'var(--ink)', padding: 22, minHeight: 130 }}><div className="t" style={{ fontSize: 28 }}>Raise your signal</div><div style={{ marginTop: 8, fontWeight: 600 }}>Tell people nearby what you need. They can reply.</div></Link>
  <Link href="/signal/search/" style={{ display: 'block', borderRadius: 30, background: 'var(--c)', color: 'var(--ink)', padding: 22, minHeight: 130, marginTop: 12 }}><div className="t" style={{ fontSize: 28 }}>Search nearby</div><div style={{ marginTop: 8, fontWeight: 600 }}>Find signals and events around you.</div></Link>
  <Link href="/signal/mine/" className="btn g" style={{ marginTop: 14 }}>My signals</Link></Shell>; }
