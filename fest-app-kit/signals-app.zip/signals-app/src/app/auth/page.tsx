'use client';
import { Suspense, useEffect, useRef, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Back } from '@/components/Bits';
import { api } from '@/lib/api';
function Auth() {
  const r = useRouter(); const signup = useSearchParams().get('m') === 'signup';
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [step, setStep] = useState<'form' | 'otp'>('form');
  const [d, setD] = useState(['', '', '', '', '', '']); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  useEffect(() => { document.documentElement.dataset.theme = api.theme(); }, []);
  const ok = /^\S+@\S+\.\S+$/.test(email) && (!signup || name.trim().length > 1);
  const send = async () => { setBusy(true); await api.sendOtp(email); setBusy(false); setStep('otp'); setTimeout(() => refs.current[0]?.focus(), 50); };
  const verify = async (digits: string[]) => { const c = digits.join(''); if (c.length < 6) return; setBusy(true);
    if (await api.verifyOtp(email, c, name)) r.replace(signup ? '/home/' : '/home/'); else { setErr('That code is not right. Try again.'); setD(['', '', '', '', '', '']); refs.current[0]?.focus(); } setBusy(false); };
  const set = (i: number, v: string) => { const x = v.replace(/\D/g, '').slice(-1); const n = [...d]; n[i] = x; setD(n); setErr(''); if (x && i < 5) refs.current[i + 1]?.focus(); if (n.every(Boolean)) verify(n); };
  return <main className="app pg">
    <Back href={step === 'otp' ? undefined : '/welcome/'}/>
    {step === 'form' ? <>
      <h1 className="t" style={{ marginTop: 14 }}>{signup ? 'Create account' : 'Welcome back'}</h1>
      <p className="mu" style={{ margin: '10px 0 22px', fontSize: 16, lineHeight: '22px' }}>We email you a 6 digit code. No password to remember.</p>
      {signup && <input className="inp" placeholder="Your name" value={name} onChange={e => setName(e.target.value)} autoComplete="name" style={{ marginBottom: 12 }}/>}
      <input className="inp" type="email" inputMode="email" placeholder="Email (use your college email)" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email"/>
      <div style={{ marginTop: 18 }}><button className="btn y" disabled={!ok || busy} onClick={send}>{busy ? 'Sending…' : 'Send code'}</button></div>
    </> : <>
      <h1 className="t" style={{ marginTop: 14 }}>Enter the code</h1>
      <p className="mu" style={{ margin: '10px 0 22px', fontSize: 16 }}>Sent to {email}. <b style={{ color: 'var(--c)' }}>Demo build: use 123456.</b></p>
      <div style={{ display: 'flex', gap: 8 }}>{d.map((v, i) => <input key={i} ref={el => { refs.current[i] = el; }} className="inp" value={v} inputMode="numeric" aria-label={`Digit ${i + 1}`} onChange={e => set(i, e.target.value)} onKeyDown={e => { if (e.key === 'Backspace' && !d[i] && i) refs.current[i - 1]?.focus(); }} style={{ padding: 0, textAlign: 'center', fontSize: 24, fontWeight: 800, height: 62 }}/>)}</div>
      <div role="alert" style={{ color: 'var(--p)', fontWeight: 700, marginTop: 12, minHeight: 20 }}>{err}</div>
      <div style={{ marginTop: 14 }}><button className="btn g" onClick={send}>Send a new code</button></div>
    </>}
  </main>;
}
export default function Page() { return <Suspense><Auth/></Suspense>; }
