'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Shell } from '@/components/Bits';
import { api, EVENTS, FEST } from '@/lib/api';
export default function Events() {
  const [reg, setReg] = useState(false); useEffect(() => setReg(api.registered()), []);
  return <Shell nav><h1 className="t">Events</h1>
    <h2 className="t" style={{ fontSize: 20, margin: '18px 0 10px' }}>My fest</h2>
    <Link href="/fest/" style={{ display: 'block', borderRadius: 28, background: 'var(--y)', color: 'var(--ink)', padding: 18 }}><span style={{ fontFamily: 'Bungee,Inter', fontSize: 30 }}>{FEST.name}</span><div style={{ fontWeight: 700, marginTop: 6 }}>{FEST.dates} · {reg ? 'Registered' : 'Not registered yet'}</div></Link>
    <h2 className="t" style={{ fontSize: 20, margin: '18px 0 10px' }}>Competitions, workshops and shows</h2>
    <div className="card">{EVENTS.map(e => <div key={e.id} className="row" style={{ padding: '10px 18px' }}><span style={{ flex: 1 }}><b>{e.title}</b><div className="mu" style={{ fontSize: 13, fontWeight: 500 }}>{e.tag} · {e.when} · {e.venue}</div></span></div>)}</div></Shell>;
}
