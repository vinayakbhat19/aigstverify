'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Shell, ICON } from '@/components/Bits';
import { api, EVENTS, FEST, timeAgo, type Signal } from '@/lib/api';
export default function Home() {
  const [s, setS] = useState<Signal[] | null>(null); const [name, setName] = useState('');
  useEffect(() => { setName(api.user()?.name ?? ''); const t = setTimeout(() => setS(api.signals().slice(0, 4)), 350); return () => clearTimeout(t); }, []);
  return <Shell nav>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><div><div className="mu" style={{ fontSize: 14, fontWeight: 600 }}>Hi {name}</div><h1 className="t">Home</h1></div>
      <Link href="/inbox/" aria-label="Messages" style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--s1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d={ICON.chat}/></svg></Link></div>
    <Link href="/fest/" className="pg" style={{ display: 'block', marginTop: 14, borderRadius: 30, background: 'var(--y)', color: 'var(--ink)', padding: 18, height: 160 }}>
      <span className="pill">Fest</span><div style={{ marginTop: 12, fontFamily: 'Bungee,Inter,sans-serif', fontSize: 38, lineHeight: 1 }}>{FEST.name}</div><div style={{ marginTop: 8, fontSize: 14, fontWeight: 700 }}>{FEST.org} · {FEST.dates}</div><div style={{ marginTop: 10, fontWeight: 800 }}>Open fest →</div></Link>
    <h2 className="t" style={{ fontSize: 20, margin: '20px 0 10px' }}>Events and competitions</h2>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>{EVENTS.slice(0, 4).map(e => <Link key={e.id} href="/events/" style={{ background: 'var(--s1)', borderRadius: 20, padding: 14, minHeight: 84 }}><span className="mu" style={{ fontSize: 12, fontWeight: 700 }}>{e.tag}</span><div style={{ fontWeight: 800, marginTop: 4 }}>{e.title}</div></Link>)}</div>
    <h2 className="t" style={{ fontSize: 20, margin: '20px 0 10px' }}>Signals raised near you</h2>
    {!s ? <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>{[0, 1, 2, 3].map(i => <div key={i} className="sk" style={{ height: 96, borderRadius: 20 }}/>)}</div>
      : <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>{s.map(x => <Link key={x.id} href={`/chat/?id=${x.id}`} style={{ background: 'color-mix(in srgb,var(--lb) 18%,var(--s1))', borderRadius: 20, padding: 14 }}><div style={{ fontWeight: 800, fontSize: 15, lineHeight: '19px' }}>{x.title}</div><div className="mu" style={{ fontSize: 12, marginTop: 6 }}>{x.where} · {x.mine ? 'yours' : timeAgo(x.ts)}</div></Link>)}</div>}
    <div style={{ textAlign: 'center', marginTop: 24 }}><Link href="/about/" className="mu" style={{ fontSize: 14, fontWeight: 700, textDecoration: 'underline' }}>About Signals</Link></div>
  </Shell>;
}
