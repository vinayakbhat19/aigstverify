'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Logo } from '@/components/Bits';
import { api } from '@/lib/api';
export default function Splash() {
  const r = useRouter();
  useEffect(() => { document.documentElement.dataset.theme = api.theme(); const t = setTimeout(() => r.replace(api.user() ? '/home/' : '/welcome/'), 1400); return () => clearTimeout(t); }, [r]);
  return <main style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16 }}><div className="pg"><Logo size={120}/></div><div className="t" style={{ fontSize: 34 }}>Signals</div></main>;
}
