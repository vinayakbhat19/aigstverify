'use client';
import { Shell, Back, Logo } from '@/components/Bits';
export default function About() { return <Shell guard={false}><Back/><Logo size={56}/><h1 className="t" style={{ marginTop: 16 }}>About Signals</h1>
  <p className="mu" style={{ fontSize: 17, lineHeight: '26px', marginTop: 12 }}>Signals shows you what is happening around you. Raise a signal when you need people for a game, a study group or a ride. Search nearby to join one. Hosts can run a whole fest from the same app.</p>
  <p className="mu" style={{ fontSize: 15, lineHeight: '22px' }}>Built at SDMCET Dharwad. Your location is only used when you search or raise a signal.</p></Shell>; }
