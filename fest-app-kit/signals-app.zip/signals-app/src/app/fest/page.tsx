'use client';
import { useEffect, useState } from 'react';
import { Shell, Back } from '@/components/Bits';
import { api, FEST, EVENTS } from '@/lib/api';
export default function Fest() {
  const [reg, setReg] = useState(false); useEffect(() => setReg(api.registered()), []);
  return <Shell><Back href="/home/"/><div style={{ fontFamily: 'Bungee,Inter', fontSize: 40, lineHeight: 1, marginTop: 6, color: 'var(--y)' }}>{FEST.name}</div><div className="mu" style={{ marginTop: 8, fontWeight: 600 }}>{FEST.org} · {FEST.dates}</div>
    <div style={{ marginTop: 18 }}>{reg ? <div className="card" style={{ padding: 18 }}><b>You are registered.</b><div className="mu" style={{ fontSize: 14, marginTop: 4 }}>Pay at the registration desk and show your QR in Me.</div></div> : <button className="btn y" onClick={() => { api.register(); setReg(true); }}>Register with my QR</button>}</div>
    <h2 className="t" style={{ fontSize: 20, margin: '22px 0 10px' }}>Map: start at the desk</h2>
    <div className="card">{FEST.venues.map((v, i) => <div key={v} className="row"><span style={{ width: 28, height: 28, borderRadius: '50%', background: i ? 'var(--s3)' : 'var(--y)', color: i ? 'var(--tx)' : 'var(--ink)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 800 }}>{i + 1}</span><span style={{ flex: 1 }}>{v}</span><span className="mu" style={{ fontSize: 13 }}>{FEST.walk[i] ? `${FEST.walk[i]} min walk` : 'Start'}</span></div>)}</div>
    <h2 className="t" style={{ fontSize: 20, margin: '22px 0 10px' }}>What is on</h2>
    <div className="card">{EVENTS.map(e => <div key={e.id} className="row"><span style={{ flex: 1 }}>{e.title}</span><span className="mu" style={{ fontSize: 13 }}>{e.when}</span></div>)}</div></Shell>;
}
