'use client';
import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Shell, Back } from '@/components/Bits';
import { api, type Msg } from '@/lib/api';
function Chat() {
  const id = useSearchParams().get('id') ?? ''; const sig = api.signals().find(s => s.id === id);
  const [m, setM] = useState<Msg[]>([]); const [t, setT] = useState(''); useEffect(() => setM(api.chat(id)), [id]);
  return <Shell><Back/><h1 className="t" style={{ marginTop: 6, fontSize: 28, lineHeight: '32px' }}>{sig?.title ?? 'Chat'}</h1><div className="mu" style={{ fontSize: 14, marginTop: 4 }}>{sig ? `${sig.by} · ${sig.where}` : ''}</div>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, margin: '20px 0 90px' }}>{m.map((x, i) => <div key={i} style={{ alignSelf: x.from === 'me' ? 'flex-end' : 'flex-start', maxWidth: '80%', padding: '10px 14px', borderRadius: 20, background: x.from === 'me' ? 'var(--lb)' : 'var(--s1)', color: x.from === 'me' ? 'var(--ink)' : 'var(--tx)', fontWeight: 600 }}>{x.text}</div>)}</div>
    <form onSubmit={e => { e.preventDefault(); if (t.trim()) { setM(api.send(id, t.trim())); setT(''); } }} style={{ position: 'fixed', left: '50%', transform: 'translateX(-50%)', bottom: 16, width: 'calc(100% - 28px)', maxWidth: 452, display: 'flex', gap: 8 }}><input className="inp" style={{ borderRadius: 28 }} placeholder="Message" value={t} onChange={e => setT(e.target.value)}/><button className="btn lb" style={{ width: 90 }}>Send</button></form></Shell>;
}
export default function Page() { return <Suspense><Chat/></Suspense>; }
