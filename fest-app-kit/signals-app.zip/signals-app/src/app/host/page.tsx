'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Shell } from '@/components/Bits';
import { api, type Draft } from '@/lib/api';
export const STEPS = ['Name, logo and theme', 'Schedule', 'Sponsors and management', 'Events, concerts and stalls', 'Map', 'Look and intro', 'Publish'];
export default function Host() {
  const [d, setD] = useState<Draft>({ step: 1 }); useEffect(() => setD(api.draft()), []);
  return <Shell nav><h1 className="t">Host your event</h1><p className="mu" style={{ fontSize: 16, lineHeight: '23px', margin: '10px 0 18px' }}>Seven steps from idea to live. Your progress is saved.</p>
    <div className="card">{STEPS.map((s, i) => <Link key={s} href={`/host/step/?n=${i + 1}`} className="row"><span style={{ width: 30, height: 30, borderRadius: '50%', background: i + 1 < d.step || d.live ? 'var(--ok)' : i + 1 === d.step ? 'var(--y)' : 'var(--s3)', color: i + 1 <= d.step || d.live ? 'var(--ink)' : 'var(--tx)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 800 }}>{i + 1}</span><span style={{ flex: 1 }}>{s}</span></Link>)}</div>
    {d.live && <div className="card" style={{ marginTop: 14, padding: 18 }}><b>{d.name} is live.</b><div className="mu" style={{ fontSize: 14, marginTop: 4 }}>Visible to {d.audience === 'everyone' ? 'everyone' : d.audience === 'link' ? 'people with the link' : 'SDMCET only'}.</div></div>}</Shell>;
}
