'use client';
import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Shell, Back } from '@/components/Bits';
import { api, type Draft } from '@/lib/api';
const STEPS = ['Name, logo and theme', 'Schedule', 'Sponsors and management', 'Events, concerts and stalls', 'Map', 'Look and intro', 'Publish'];
const TYPES = ['Fest', 'Competition', 'Workshop', 'Event'];
function F({ k, d, set, ph, area }: { k: keyof Draft; d: Draft; set: (p: Partial<Draft>) => void; ph: string; area?: boolean }) {
  const p = { className: 'inp', placeholder: ph, value: (d[k] as string) ?? '', onChange: (e: React.ChangeEvent<HTMLInputElement & HTMLTextAreaElement>) => set({ [k]: e.target.value } as Partial<Draft>), style: { marginTop: 12 } as React.CSSProperties };
  return area ? <textarea {...p} style={{ ...p.style, height: 120, padding: 14, resize: 'none' }}/> : <input {...p}/>;
}
function Step() {
  const r = useRouter(); const n = Math.min(7, Math.max(1, +(useSearchParams().get('n') ?? 1)));
  const [d, setD] = useState<Draft>({ step: 1 }); useEffect(() => setD(api.draft()), []);
  const set = (p: Partial<Draft>) => { const x = { ...d, ...p }; setD(x); api.saveDraft(x); };
  const next = () => { const x = { ...d, step: Math.max(d.step, n + 1) }; api.saveDraft(x); r.push(n < 7 ? `/host/step/?n=${n + 1}` : '/host/'); };
  const publish = () => { api.saveDraft({ ...d, live: true, step: 7 }); r.push('/host/'); };
  return <Shell nav><Back href={n > 1 ? `/host/step/?n=${n - 1}` : '/host/'}/><div className="mu" style={{ fontSize: 13, fontWeight: 700, marginTop: 4 }}>Step {n} of 7</div><h1 className="t" style={{ fontSize: 32, lineHeight: '36px', marginTop: 4 }}>{STEPS[n - 1]}</h1>
    <div style={{ height: 4, borderRadius: 2, background: 'var(--s2)', margin: '14px 0 6px' }}><div style={{ width: `${n / 7 * 100}%`, height: 4, borderRadius: 2, background: 'var(--y)', transition: 'width .3s' }}/></div>
    {n === 1 && <><div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 14 }}>{TYPES.map(t => <button key={t} aria-pressed={d.type === t} onClick={() => set({ type: t })} style={{ height: 44, padding: '0 18px', borderRadius: 22, fontWeight: 700, background: d.type === t ? 'var(--y)' : 'var(--s1)', color: d.type === t ? 'var(--ink)' : 'var(--tx)' }}>{t}</button>)}</div><F k="name" d={d} set={set} ph="Event name"/><F k="theme" d={d} set={set} ph="Theme, for example Retro arcade"/></>}
    {n === 2 && <><F k="start" d={d} set={set} ph="Starts (date and time)"/><F k="end" d={d} set={set} ph="Ends (date and time)"/><F k="venue" d={d} set={set} ph="Main venue"/></>}
    {n === 3 && <><F k="sponsors" d={d} set={set} ph="Sponsors, one per line" area/><p className="mu" style={{ fontSize: 14 }}>Only you, the host, give roles and access. Coordinators manage only their own events.</p></>}
    {n === 4 && <F k="programme" d={d} set={set} ph="Competitions, concert, stalls, one per line" area/>}
    {n === 5 && <><p className="mu" style={{ fontSize: 16, lineHeight: '23px' }}>Visitors see the registration desk first, then each venue with walking times.</p><F k="venue" d={d} set={set} ph="Registration desk location"/></>}
    {n === 6 && <F k="intro" d={d} set={set} ph="Welcome message for your visitors" area/>}
    {n === 7 && <><p className="mu" style={{ fontSize: 16 }}>Who can see {d.name || 'your event'}?</p>{(['sdmcet', 'everyone', 'link'] as const).map(a => <button key={a} onClick={() => set({ audience: a })} aria-pressed={d.audience === a} style={{ display: 'block', width: '100%', textAlign: 'left', marginTop: 10, padding: 16, borderRadius: 22, fontWeight: 700, background: 'var(--s1)', border: `2px solid ${d.audience === a ? 'var(--y)' : 'transparent'}` }}>{a === 'sdmcet' ? 'Only SDMCET' : a === 'everyone' ? 'Everyone' : 'Anyone with the link'}</button>)}</>}
    <div style={{ marginTop: 22 }}>{n < 7 ? <button className="btn y" onClick={next}>Save and continue</button> : <button className="btn y" disabled={!d.audience || !d.name} onClick={publish}>Publish</button>}</div></Shell>;
}
export default function Page() { return <Suspense><Step/></Suspense>; }
