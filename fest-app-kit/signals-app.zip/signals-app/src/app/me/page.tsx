'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import QR from 'qrcode';
import { Shell } from '@/components/Bits';
import { api, type User } from '@/lib/api';
export default function Me() {
  const r = useRouter(); const [u, setU] = useState<User | null>(null); const [qr, setQr] = useState(''); const [theme, setTheme] = useState<'dark' | 'light'>('dark'); const [conf, setConf] = useState(false);
  useEffect(() => { setU(api.user()); setTheme(api.theme()); QR.toDataURL(api.qr(), { margin: 1, width: 360, color: { dark: '#0A0A0A', light: '#FFFFFF' } }).then(setQr); }, []);
  const share = async () => { try { if (navigator.share) await navigator.share({ title: 'My Signals QR', text: 'Find me on Signals', url: location.origin }); else await navigator.clipboard.writeText(location.origin); } catch {} };
  const flip = () => { const t = theme === 'dark' ? 'light' : 'dark'; api.setTheme(t); setTheme(t); document.documentElement.dataset.theme = t; };
  return <Shell nav><h1 className="t">Me</h1>
    <div className="card" style={{ marginTop: 16, padding: 20, textAlign: 'center' }}>
      <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'var(--p)', color: 'var(--ink)', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, fontWeight: 800 }}>{u?.name?.[0]?.toUpperCase()}</div>
      <div className="t" style={{ fontSize: 24, marginTop: 10 }}>{u?.name}</div><div className="mu" style={{ fontSize: 14 }}>{u?.email}</div>{u?.college && <div style={{ marginTop: 8 }}><span className="pill">{u.college}</span></div>}
      {qr && <img src={qr} alt="My QR code" width={180} height={180} style={{ borderRadius: 16, marginTop: 16, background: '#fff', padding: 6 }}/>}
      <div className="mu" style={{ fontSize: 12, marginTop: 6 }}>Works offline. Show it at the registration desk.</div>
      <div style={{ marginTop: 14 }}><button className="btn y" onClick={share}>Share QR</button></div></div>
    <div className="card" style={{ marginTop: 14 }}>
      <Link href="/signal/mine/" className="row">My signals</Link>
      <button className="row" onClick={flip}><span style={{ flex: 1 }}>Theme</span><span className="mu">{theme === 'dark' ? 'Dark' : 'Light'}</span></button>
      <Link href="/about/" className="row">About Signals</Link>
      <button className="row" onClick={() => { api.signOut(); r.replace('/welcome/'); }}>Sign out</button>
      <button className="row" style={{ color: 'var(--p)' }} onClick={() => conf ? (api.deleteAccount(), r.replace('/welcome/')) : setConf(true)}>{conf ? 'Tap again to delete everything' : 'Delete account'}</button></div></Shell>;
}
