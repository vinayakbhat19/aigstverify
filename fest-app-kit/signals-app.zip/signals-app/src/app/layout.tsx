import type { Metadata, Viewport } from 'next';
import './globals.css';
import SW from '@/components/SW';
export const metadata: Metadata = { title: 'Signals', description: 'Raise a signal. Find what is happening around you.', manifest: '/manifest.webmanifest', appleWebApp: { capable: true, title: 'Signals', statusBarStyle: 'black-translucent' } };
export const viewport: Viewport = { themeColor: '#000000', width: 'device-width', initialScale: 1, viewportFit: 'cover' };
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en" data-theme="dark"><head><link rel="preconnect" href="https://fonts.googleapis.com"/><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Bungee&display=swap" rel="stylesheet"/><link rel="apple-touch-icon" href="/icon-192.png"/></head><body>{children}<SW/></body></html>;
}
