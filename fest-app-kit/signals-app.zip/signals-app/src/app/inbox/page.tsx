'use client';
import Link from 'next/link';
import { Shell, Back } from '@/components/Bits';
import { api } from '@/lib/api';
export default function Inbox() { const s = api.signals().slice(0, 4); return <Shell nav><Back href="/home/"/><h1 className="t" style={{ marginTop: 10 }}>Messages</h1><div className="card" style={{ marginTop: 18 }}>{s.map(x => { const last = api.chat(x.id).slice(-1)[0]; return <Link key={x.id} href={`/chat/?id=${x.id}`} className="row" style={{ padding: '10px 18px' }}><span style={{ flex: 1, minWidth: 0 }}><b>{x.by}</b><div className="mu" style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{last?.text}</div></span></Link>; })}</div></Shell>; }
