'use client';
import Link from 'next/link';
import { useEffect } from 'react';
import { Logo } from '@/components/Bits';
import { api } from '@/lib/api';
export default function Welcome() {
  useEffect(() => { document.documentElement.dataset.theme = api.theme(); }, []);
  return <main className="app pg" style={{ display: 'flex', flexDirection: 'column', minHeight: '100dvh' }}>
    <Logo size={64}/>
    <h1 className="t" style={{ marginTop: 28, fontSize: 52, lineHeight: .98 }}>Raise a signal.<br/>Find your people.</h1>
    <p className="mu" style={{ fontSize: 17, lineHeight: '24px', marginTop: 14 }}>See what is happening around you on campus, join in, or host your own event.</p>
    <div style={{ flex: 1 }}/>
    <Link href="/auth/?m=signup" className="btn y">Create account</Link>
    <Link href="/auth/?m=login" className="btn g" style={{ marginTop: 10 }}>I already have one</Link>
  </main>;
}
