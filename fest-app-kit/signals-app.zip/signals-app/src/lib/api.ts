'use client';
/**
 * Data layer. Today it is backed by localStorage so the whole app works offline
 * and without a database. To go live, swap each function body for a Supabase
 * call (see /supabase/schema.sql) - screens never touch storage directly.
 */
export type User = { name: string; email: string; college: string; interests: string[]; verified: boolean };
export type Signal = { id: string; title: string; kind: 'Study' | 'Sport' | 'Food' | 'Ride' | 'Other'; where: string; mins: number; by: string; mine?: boolean; joined?: number; ts: number };
export type Msg = { from: 'me' | 'them'; text: string; ts: number };
export type Draft = { type?: string; name?: string; theme?: string; start?: string; end?: string; sponsors?: string; programme?: string; venue?: string; intro?: string; audience?: 'sdmcet' | 'everyone' | 'link'; step: number; live?: boolean };

const K = { user: 'sg.user', signals: 'sg.signals', chats: 'sg.chats', theme: 'sg.theme', draft: 'sg.draft', otp: 'sg.otp', reg: 'sg.reg' };
const rd = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };
const wr = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

const SEED: Signal[] = [
  { id: 's1', title: 'Need a 4th for badminton', kind: 'Sport', where: 'Sports complex', mins: 12, by: 'Aarav', ts: Date.now() - 6e5, joined: 2 },
  { id: 's2', title: 'DSA doubts before the test', kind: 'Study', where: 'Library, 2nd floor', mins: 5, by: 'Meera', ts: Date.now() - 12e5, joined: 3 },
  { id: 's3', title: 'Sharing an auto to Vidyagiri', kind: 'Ride', where: 'Main gate', mins: 3, by: 'Rohan', ts: Date.now() - 3e5, joined: 1 },
  { id: 's4', title: 'Chai at the canteen?', kind: 'Food', where: 'Canteen', mins: 8, by: 'Isha', ts: Date.now() - 9e5, joined: 4 },
];
export const FEST = { name: "FIESTA'26", org: 'SDMCET Dharwad', dates: '25 to 28 Nov', venues: ['Registration desk', 'Main stage', 'Auto expo ground', 'Stalls lane', 'Seminar hall'], walk: [0, 3, 6, 4, 8] };
export const EVENTS = [
  { id: 'e1', title: 'Hackathon 24h', tag: 'Competition', when: '25 Nov, 9:00', venue: 'CS block' },
  { id: 'e2', title: 'Robo Race', tag: 'Competition', when: '26 Nov, 11:00', venue: 'Auto expo ground' },
  { id: 'e3', title: 'Design Sprint', tag: 'Workshop', when: '26 Nov, 14:00', venue: 'Seminar hall' },
  { id: 'e4', title: 'Main concert', tag: 'Show', when: '27 Nov, 19:00', venue: 'Main stage' },
];

export const api = {
  theme: () => rd<'dark' | 'light'>(K.theme, 'dark'),
  setTheme: (t: 'dark' | 'light') => wr(K.theme, t),
  user: () => rd<User | null>(K.user, null),
  /** Step 1 of sign up. Real build: supabase.auth.signInWithOtp({email}). Demo code is 123456. */
  sendOtp: async (email: string) => { wr(K.otp, { email, code: '123456' }); return true; },
  /** Step 2. Real build: supabase.auth.verifyOtp. */
  verifyOtp: async (email: string, code: string, name: string) => {
    const o = rd<{ email: string; code: string } | null>(K.otp, null);
    if (!o || o.email !== email || o.code !== code) return false;
    const college = /@sdmcet\.ac\.in$/i.test(email) ? 'SDMCET Dharwad' : '';
    wr(K.user, { name: name || email.split('@')[0], email, college, interests: [], verified: !!college } satisfies User);
    return true;
  },
  updateUser: (p: Partial<User>) => { const u = api.user(); if (u) wr(K.user, { ...u, ...p }); },
  signOut: () => { try { localStorage.removeItem(K.user); } catch {} },
  deleteAccount: () => { try { Object.values(K).forEach(k => localStorage.removeItem(k)); } catch {} },
  signals: () => [...rd<Signal[]>(K.signals, []), ...SEED].sort((a, b) => b.ts - a.ts),
  mine: () => rd<Signal[]>(K.signals, []),
  raise: (s: Pick<Signal, 'title' | 'kind' | 'where'>) => {
    const u = api.user(); const n: Signal = { ...s, id: 'm' + Date.now(), mins: 0, by: u?.name ?? 'You', mine: true, ts: Date.now(), joined: 0 };
    wr(K.signals, [n, ...api.mine()]); return n;
  },
  close: (id: string) => wr(K.signals, api.mine().filter(s => s.id !== id)),
  chat: (id: string) => rd<Msg[]>(K.chats + id, [{ from: 'them', text: 'Hey! Saw your signal. Still on?', ts: Date.now() - 6e4 }]),
  send: (id: string, text: string) => { const m = [...api.chat(id), { from: 'me' as const, text, ts: Date.now() }]; wr(K.chats + id, m); return m; },
  /** QR payload. Real build: server-signed token so desks can verify offline. */
  qr: () => { const u = api.user(); return u ? `SIGNALS1|${u.email}|${FEST.name}` : ''; },
  registered: () => rd<boolean>(K.reg, false),
  register: () => wr(K.reg, true),
  draft: () => rd<Draft>(K.draft, { step: 1 }),
  saveDraft: (d: Draft) => wr(K.draft, d),
};

export const timeAgo = (ts: number) => { const m = Math.max(1, Math.round((Date.now() - ts) / 6e4)); return m < 60 ? `${m} min ago` : `${Math.round(m / 60)} h ago`; };
