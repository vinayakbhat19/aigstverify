'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState, type ReactNode } from 'react';
import { api } from '@/lib/api';

export const Logo = ({ size = 38 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 120 120" aria-hidden="true"><g fill="none" strokeWidth="10" strokeLinecap="round"><path d="M44.4 76.4A22 22 0 0 1 75.6 76.4" stroke="#FFD60A"/><path d="M33.1 65.1A38 38 0 0 1 86.9 65.1" stroke="#FF4FD8"/><path d="M21.8 53.8A54 54 0 0 1 98.2 53.8" stroke="#9B6CFF"/></g><circle cx="60" cy="92" r="10" fill="#22D3EE"/></svg>
);
const I = ({ d }: { d: string }) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d}/></svg>;
export const ICON = {
  home: 'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
  events: 'M4 5h16v15H4zM4 10h16M9 3v4M15 3v4',
  host: 'M12 5v14M5 12h14',
  me: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21c0-4 4-6 8-6s8 2 8 6',
  back: 'M15 6l-6 6 6 6',
  bell: 'M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7M10 20a2 2 0 0 0 4 0',
  chat: 'M4 5h16v11H9l-5 4z',
};

export function Back({ href }: { href?: string }) {
  const r = useRouter();
  const cls = { width: 44, height: 44, marginLeft: -10, display: 'flex', alignItems: 'center', justifyContent: 'center' } as const;
  return href ? <Link href={href} aria-label="Back" style={cls}><I d={ICON.back}/></Link> : <button onClick={() => r.back()} aria-label="Back" style={cls}><I d={ICON.back}/></button>;
}

/** Wraps every screen: theme, offline banner, auth guard. */
export function Shell({ children, nav, guard = true }: { children: ReactNode; nav?: boolean; guard?: boolean }) {
  const r = useRouter(); const [ready, setReady] = useState(false); const [off, setOff] = useState(false);
  useEffect(() => {
    document.documentElement.dataset.theme = api.theme();
    if (guard && !api.user()) { r.replace('/welcome/'); return; }
    setReady(true);
    const f = () => setOff(!navigator.onLine); f();
    addEventListener('online', f); addEventListener('offline', f);
    return () => { removeEventListener('online', f); removeEventListener('offline', f); };
  }, [guard, r]);
  if (!ready) return <main className="app"><div className="sk" style={{ height: 40, width: 160 }}/><div className="sk" style={{ height: 180, marginTop: 20, borderRadius: 30 }}/><div className="sk" style={{ height: 84, marginTop: 18, borderRadius: 20 }}/></main>;
  return <>{off && <div className="offline" role="status">No network · showing saved data</div>}<main className="app pg">{children}</main>{nav && <Nav/>}</>;
}

export function Nav() {
  const p = usePathname(); const on = (x: string) => p.startsWith(x);
  const L = ({ href, label, ic }: { href: string; label: string; ic: string }) => <Link href={href} className={'nv' + (on(href) ? ' on' : '')} aria-current={on(href) ? 'page' : undefined}><I d={ic}/>{label}</Link>;
  return <nav className="nav" aria-label="Main">
    <L href="/home/" label="Home" ic={ICON.home}/><L href="/events/" label="Events" ic={ICON.events}/>
    <Link href="/signal/" className="coin" aria-label="Signal: raise yours or search nearby"><Logo/></Link>
    <L href="/host/" label="Host" ic={ICON.host}/><L href="/me/" label="Me" ic={ICON.me}/>
  </nav>;
}
